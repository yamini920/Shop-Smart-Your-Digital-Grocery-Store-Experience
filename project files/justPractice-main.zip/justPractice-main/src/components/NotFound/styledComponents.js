import styled from 'styled-components'

export const NotFoundContainer = styled.div`
padding-top:10vh;
    height:100vh;
    background-color:#575656;
`